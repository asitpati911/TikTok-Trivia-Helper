# -*- coding: utf-8 -*-
# The file used to store the history of commands
HISTORY_FILE = 'psh_history'
# The startup script file
STARTUP_FILE = 'pshrc'
