# -*- coding: utf-8 -*-
FILESYSTEM_COLLECTION = 'pyos_fs'
PYOS_COLLECTION = 'pyos'
SETTINGS_VERSION = 'version'
