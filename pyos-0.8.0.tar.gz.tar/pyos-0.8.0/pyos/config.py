# -*- coding: utf-8 -*-
__all__ = 'DIR_KEY', 'NAME_KEY', 'KEYS'

DIR_KEY = '_directory'
NAME_KEY = 'name'

KEYS = (DIR_KEY, NAME_KEY)
